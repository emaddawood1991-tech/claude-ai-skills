# Website UI Style Menu

Use this file as the style choice menu inside the single `website-style-selector` cloud skill.

## 1. Skeuomorphism UI

Real-world imitation. Interface elements look physical and tactile.

Use for premium product websites, wallets, calendars, tools, education, craft, coffee, and luxury products.

Design rules:

- Use real-world materials: leather, paper, metal, wood, ceramic, fabric, or plastic.
- Use bevels, grooves, shadows, highlights, and realistic pressable controls.
- Keep typography modern so the UI does not feel outdated.

Prompt:

“Design this website in a refined skeuomorphic UI style with realistic tactile materials, pressable controls, bevels, physical shadows, premium highlights, and modern readable typography.”

## 2. Neumorphism UI

Soft UI where elements look gently raised from or pressed into the background.

Use for wellness apps, finance dashboards, calm productivity tools, calculators, settings, and control panels.

Design rules:

- Use soft raised cards and subtle inset controls.
- Pair light and dark shadows.
- Use calm low-contrast surfaces with one clear accent color.
- Keep text and CTAs accessible with enough contrast.

Prompt:

“Design this website in a neumorphic UI style with soft raised cards, subtle inner shadows, rounded controls, calm surfaces, gentle depth, and accessible contrast.”

## 3. Glassmorphism UI

Transparent glass layers with frosted blur, thin borders, gradients, and depth.

Use for AI products, SaaS landing pages, fintech dashboards, futuristic portfolios, and premium hero sections.

Design rules:

- Use translucent panels with backdrop blur.
- Add thin glass borders and soft highlights.
- Use gradients or abstract backgrounds behind the glass.
- Protect readability with contrast overlays.

Prompt:

“Design this website in a glassmorphism UI style with translucent frosted panels, background blur, glowing gradients, thin glass borders, layered depth, and strong readability.”

## 4. Claymorphism UI

Playful soft 3D UI with clay-like or inflated shapes.

Use for kids apps, gamified products, friendly ecommerce, creative landing pages, and playful consumer brands.

Design rules:

- Use chunky rounded shapes.
- Use soft 3D shadows and friendly color.
- Use simple 3D icons, blobs, badges, and illustrations.
- Keep layout simple so it does not become childish or messy.

Prompt:

“Design this website in a claymorphism UI style with soft 3D clay-like cards, rounded inflated shapes, playful shadows, friendly colors, and approachable depth.”

## 5. Minimalism UI

Clean, focused UI with only necessary elements.

Use for professional SaaS, clinic systems, productivity tools, corporate websites, luxury brands, admin panels, and forms.

Design rules:

- Use generous whitespace.
- Use restrained color and crisp typography.
- Keep hierarchy clear and actions obvious.
- Remove decoration that does not support the user goal.

Prompt:

“Design this website in a minimalist UI style with clean hierarchy, generous whitespace, restrained color, crisp typography, simple components, and only essential UI elements.”

## 6. Maximalism UI

Bold, expressive, colorful, layered, and visually rich.

Use for fashion campaigns, music/event pages, creative portfolios, youth ecommerce, launches, and brand activations.

Design rules:

- Use bold colors, expressive typography, layered graphics, stickers, patterns, and motion.
- Keep CTAs and conversion path clear.
- Use intentional hierarchy so the design feels energetic, not chaotic.

Prompt:

“Design this website in a maximalist UI style with bold colors, expressive typography, layered graphics, energetic composition, rich visual density, and a clear conversion path.”

## 7. Brutalism UI

Raw, rough, direct, anti-polished interface design.

Use for experimental portfolios, developer tools, underground brands, editorial projects, music, art, and internet-culture websites.

Design rules:

- Use hard borders, visible grids, plain colors, oversized typography, and stark contrast.
- Make interactions obvious and direct.
- Keep usability clear even when the visuals feel rough.

Prompt:

“Design this website in a brutalist UI style with raw layout, hard borders, oversized typography, stark contrast, visible grid structure, direct controls, and intentionally unpolished energy.”

## 8. Neoglass / Liquid Glass UI

Premium shiny translucent UI with luminous glass, soft refraction, and platform-level polish.

Use for premium SaaS, AI assistants, iOS/macOS-style apps, luxury dashboards, and high-end product websites.

Design rules:

- Use luminous translucent panels, soft refraction, glass shine, and floating depth.
- Use clean typography and elegant highlights.
- Keep contrast stronger than decorative glassmorphism.
- Use subtle hover shine or motion-responsive effects when coding.

Prompt:

“Design this website in a neoglass liquid-glass UI style with luminous translucent surfaces, soft refraction, premium highlights, floating depth, clean typography, and elegant platform-level polish.”

## 9. Bento Grid UI

Organized card-based layout with modular content blocks.

Use for SaaS homepages, feature sections, portfolio case studies, dashboards, Apple-style marketing layouts, and AI product showcases.

Design rules:

- Use modular cards with varied sizes.
- Make each card communicate one idea.
- Mix icons, screenshots, metrics, short copy, charts, and CTAs.
- Keep spacing, rhythm, and hierarchy strong.

Prompt:

“Design this website in a bento grid UI style with modular cards, varied card sizes, clear feature hierarchy, premium spacing, visual rhythm, fast scanability, and polished content blocks.”

## 10. Spatial UI

Interface design for 3D space, AR, VR, mixed reality, or immersive product concepts.

Use for AR/VR apps, Vision-style apps, 3D dashboards, immersive education, spatial demos, and floating control panels.

Design rules:

- Use floating depth-aware panels.
- Use readable scale and comfortable spacing.
- Make controls gesture, gaze, pointer, or hand friendly.
- Use soft translucent materials and calm motion.
- Avoid tiny text, dense tables, and motion discomfort.

Prompt:

“Design this website as a spatial UI with floating depth-aware panels, readable scale, gesture-friendly controls, soft translucent materials, calm motion, and immersive hierarchy.”

## Fast recommendations

| User goal | Best style |
| --- | --- |
| Clean professional website | Minimalism UI |
| Premium AI/SaaS website | Neoglass UI or Glassmorphism UI |
| Organized feature page | Bento Grid UI |
| Friendly playful product | Claymorphism UI |
| Calm wellness dashboard | Neumorphism UI |
| Bold creative campaign | Maximalism UI |
| Raw experimental portfolio | Brutalism UI |
| Realistic tactile product UI | Skeuomorphism UI |
| AR/VR concept | Spatial UI |
