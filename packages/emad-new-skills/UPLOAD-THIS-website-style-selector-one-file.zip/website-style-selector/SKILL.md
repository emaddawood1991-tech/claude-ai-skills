---
name: website-style-selector
description: Choose and apply one of 10 website UI design styles from a single cloud-uploadable skill: skeuomorphism, neumorphism, glassmorphism, claymorphism, minimalism, maximalism, brutalism, neoglass/liquid glass, bento grid, and spatial UI. Use when the user wants to build, redesign, prompt, or code a website/app interface and wants to choose a specific visual style inside one skill.
---

# Website Style Selector

Use this skill as one accepted cloud skill that contains a menu of 10 website UI styles.

The cloud only accepts one skill per ZIP, so this package is intentionally one skill with style choices inside it. When the user asks for a website/app design, ask them to choose a style if they did not already name one.

## Style menu

Read `references/style-menu.md` and select one style:

1. Skeuomorphism UI
2. Neumorphism UI
3. Glassmorphism UI
4. Claymorphism UI
5. Minimalism UI
6. Maximalism UI
7. Brutalism UI
8. Neoglass / Liquid Glass UI
9. Bento Grid UI
10. Spatial UI

## Workflow

1. Identify product type: landing page, ecommerce, SaaS dashboard, clinic system, admin panel, mobile app, portfolio, or AR/VR interface.
2. Ask the user to choose one style if missing.
3. Load the selected style from `references/style-menu.md`.
4. Convert the chosen style into practical UI decisions: layout, colors, typography, components, spacing, shadows, materials, and motion.
5. If writing code, implement the style in real CSS/components instead of only naming the style.

## Output format

When giving design direction, include:

- Selected style
- Best use case
- Layout structure
- Color palette
- Typography direction
- Component treatment
- Motion/interactions
- Accessibility warnings

When generating an AI prompt, include the selected style name clearly at the beginning.
