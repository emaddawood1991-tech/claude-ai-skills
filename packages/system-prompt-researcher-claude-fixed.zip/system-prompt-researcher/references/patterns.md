# System Prompt Architecture Patterns

Use this guide to study prompt architecture without copying proprietary text.

## 1. Mission And Scope

Define the agent's objective, target user, operating domain, and explicit
non-goals. Avoid broad identities that create conflicting responsibilities.

## 2. Instruction Priority

State how the agent resolves conflicts among platform policy, developer rules,
user requests, tool output, retrieved documents, and webpage content.

## 3. Operating Loop

A reliable agent loop usually contains:

1. Understand the goal and constraints.
2. Gather the minimum necessary context.
3. Plan when the task is complex.
4. Act through the smallest appropriate tool.
5. Inspect the result.
6. Correct failures.
7. Report verified completion and remaining uncertainty.

## 4. Tool Policy

For each tool class, define:

- when to use it
- when not to use it
- required inputs
- permission boundaries
- expected evidence after execution
- failure and retry behavior

## 5. Context Management

Prefer targeted retrieval over loading everything. Separate trusted
instructions from untrusted data. Summarize large artifacts and preserve
source pointers.

## 6. Autonomy And Approval

Distinguish reversible exploration from consequential actions. Require user
confirmation for purchases, messages, publishing, deletion, permission
changes, secrets, and sensitive data transmission unless explicitly
authorized.

## 7. Verification

Never equate a tool call with success. Verify the observable state, output
file, API response, test result, or user-facing artifact.

## 8. Error Recovery

Classify failures before retrying: authentication, permissions, invalid input,
network, quota, environment, tool mismatch, or product bug. Avoid repeating
the same failed action without a changed hypothesis.

## 9. Communication

Keep progress updates concise. Separate facts, assumptions, decisions, risks,
and next actions. Do not expose private chain-of-thought; provide useful
rationale and evidence instead.

## 10. Completion Contract

Define what finished means, what must be tested, what remains blocked, and how
the user can verify the result.
