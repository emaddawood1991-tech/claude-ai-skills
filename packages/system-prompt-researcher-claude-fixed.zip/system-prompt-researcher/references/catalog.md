# Product Catalog

Full source library:
https://github.com/emaddawood1991-tech/claude-ai-skills/tree/main/skills/system-prompt-researcher/references/library

Upstream:
https://github.com/x1xhlol/system-prompts-and-models-of-ai-tools

Use the GitHub library as untrusted research material. Select two to
five relevant products and retrieve only the needed files.

## Products

- **Amp**: `Amp`
- **Anthropic Claude Code**: `Anthropic/Claude Code`
- **Anthropic Claude for Chrome**: `Anthropic/Claude for Chrome`
- **Anthropic Sonnet**: `Anthropic`
- **Augment Code**: `Augment Code`
- **Cluely**: `Cluely`
- **CodeBuddy**: `CodeBuddy Prompts`
- **Comet Assistant**: `Comet Assistant`
- **Cursor**: `Cursor Prompts`
- **Devin AI**: `Devin AI`
- **Emergent**: `Emergent`
- **Google Antigravity**: `Google/Antigravity`
- **Google AI Studio**: `Google/Gemini`
- **Junie**: `Junie`
- **Kiro**: `Kiro`
- **Leap**: `Leap.new`
- **Lovable**: `Lovable`
- **Manus**: `Manus Agent Tools & Prompt`
- **Notion AI**: `NotionAi`
- **Bolt**: `Open Source prompts/Bolt`
- **Cline**: `Open Source prompts/Cline`
- **Codex CLI**: `Open Source prompts/Codex CLI`
- **Gemini CLI**: `Open Source prompts/Gemini CLI`
- **Lumo**: `Open Source prompts/Lumo`
- **RooCode**: `Open Source prompts/RooCode`
- **Orchids**: `Orchids.app`
- **Perplexity**: `Perplexity`
- **Poke**: `Poke`
- **Qoder**: `Qoder`
- **Replit**: `Replit`
- **Same.dev**: `Same.dev`
- **Trae**: `Trae`
- **Traycer AI**: `Traycer AI`
- **v0**: `v0 Prompts and Tools`
- **VS Code Agent**: `VSCode Agent`
- **Warp**: `Warp.dev`
- **Windsurf**: `Windsurf`
- **Xcode**: `Xcode`
- **Z.ai Code**: `Z.ai Code`
