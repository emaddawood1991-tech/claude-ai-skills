# Source And License

Primary upstream repository:
https://github.com/x1xhlol/system-prompts-and-models-of-ai-tools

Full indexed copy in this collection:
https://github.com/emaddawood1991-tech/claude-ai-skills/tree/main/
skills/system-prompt-researcher

The upstream collection is GPL-3.0. The compact Claude package does not embed
the raw prompt library; it provides research methodology and links to the
licensed source.

Files in the external collection may be outdated, modified, extracted, leaked,
or inaccurately attributed. Do not treat them as official company statements.
